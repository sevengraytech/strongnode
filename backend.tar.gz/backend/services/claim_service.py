from sqlalchemy.orm import Session
from sqlalchemy import func, desc, case
from backend.models.models import ClaimBlack, ClaimStatus, User
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

class ClaimService:
    """
    Professional scam recovery service for forensic analysis and case management.
    """
    
    def __init__(self, db: Session):
        self.db = db
    
    def calculate_priority(self, report_data: dict) -> int:
        """
        AI-driven case priority scoring (1-5).
        Higher priority = faster specialist assignment.
        """
        score = 1
        
        # Amount invested (major factor)
        if report_data.get('amount_invested', 0) > 100000:
            score = 5
        elif report_data.get('amount_invested', 0) > 50000:
            score = 4
        elif report_data.get('amount_invested', 0) > 10000:
            score = 3
        elif report_data.get('amount_invested', 0) > 1000:
            score = 2
        
        # Scam type urgency
        urgent_scams = ['pig_butchering', 'romance_scam', 'rug_pull', 'ponzi']
        if any(s in report_data.get('scam_type', '').lower() for s in urgent_scams):
            score += 1
        
        # Geographic priority (high-risk regions)
        high_risk_countries = ['NG', 'PH', 'IN', 'PK', 'BD']
        if report_data.get('country', '').upper() in [c.upper() for c in high_risk_countries]:
            score += 1
        
        return min(score, 5)
    
    def triage_case(self, claim_record: ClaimBlack):
        """
        Auto-triage and specialist assignment based on priority.
        """
        # Auto-assign specialists by priority/amount
        specialists = {
            5: 'dr.johnson@recoveryteam.com',  # Elite recovery specialist
            4: 'analyst.smith@recoveryteam.com',
            3: 'sr.analyst.lee@recoveryteam.com',
            2: 'analyst.wilson@recoveryteam.com',
            1: 'jr.analyst.davis@recoveryteam.com'
        }
        
        claim_record.assigned_specialist = specialists.get(claim_record.priority, 'triage@recoveryteam.com')
        claim_record.status = ClaimStatus.UNDER_REVIEW.value
        
        # High priority gets immediate status update
        if claim_record.priority >= 4:
            claim_record.status = ClaimStatus.IN_PROGRESS.value
        
        logger.info(f"Case {claim_record.case_id} triaged to {claim_record.assigned_specialist} (priority {claim_record.priority})")
    
    @staticmethod
    def get_status_message(status: str) -> str:
        """Human-readable status messages."""
        messages = {
            ClaimStatus.PENDING.value: "📥 Case received - Awaiting triage",
            ClaimStatus.UNDER_REVIEW.value: "🔍 Forensic analysis in progress",
            ClaimStatus.IN_PROGRESS.value: "⚡ Active recovery operation",
            ClaimStatus.RECOVERED.value: "✅ Funds successfully recovered!",
            ClaimStatus.CLOSED.value: "🔒 Case completed",
            ClaimStatus.REJECTED.value: "❌ Case declined"
        }
        return messages.get(status, "Unknown status")
    
    def get_recovery_stats(self) -> dict:
        """Comprehensive recovery program statistics."""
        stats = self.db.query(
            func.count(ClaimBlack.id).label('total_cases'),
            func.count(ClaimBlack.id).filter(ClaimBlack.status == ClaimStatus.RECOVERED.value).label('recovered'),
            func.coalesce(func.sum(ClaimBlack.amount_recovered), 0).label('total_recovered'),
            func.coalesce(func.avg(ClaimBlack.recovery_days), 0).label('avg_days'),
            func.count(ClaimBlack.id).filter(ClaimBlack.priority >= 4).label('high_priority')
        ).one()
        
        total_invested = self.db.query(func.sum(ClaimBlack.amount_invested)).scalar() or 0
        
        return {
            'total_cases': int(stats.total_cases or 0),
            'recovery_rate': round((stats.recovered / stats.total_cases * 100), 1) if stats.total_cases else 0,
            'total_recovered_usd': float(stats.total_recovered or 0),
            'total_claimed_usd': float(total_invested),
            'avg_recovery_days': int(stats.avg_days or 0),
            'high_priority_cases': int(stats.high_priority or 0),
            'pending_cases': self.db.query(ClaimBlack).filter(ClaimBlack.status == ClaimStatus.PENDING.value).count()
        }
    
    def get_recent_successes(self, db: Session, limit: int = 5) -> list:
        """Get anonymized recent success stories."""
        rows = db.query(
            ClaimBlack.case_id,
            ClaimBlack.country,
            ClaimBlack.scam_type,
            ClaimBlack.amount_recovered,
            ClaimBlack.recovery_days
        ).filter(
            ClaimBlack.status == ClaimStatus.RECOVERED.value
        ).order_by(desc(ClaimBlack.updated_at)).limit(limit).all()

        return [
            {
                "case_id": row.case_id,
                "country": row.country,
                "scam_type": row.scam_type,
                "amount_recovered": float(row.amount_recovered or 0),
                "days_to_recover": row.recovery_days,
            }
            for row in rows
        ]
    
    def get_pending_cases(self, page: int = 1, per_page: int = 20) -> dict:
        """Admin: Get paginated pending claims."""
        offset = (page - 1) * per_page
        total = self.db.query(ClaimBlack).filter(
            ClaimBlack.status.in_([ClaimStatus.PENDING.value, ClaimStatus.UNDER_REVIEW.value])
        ).count()
        
        cases = self.db.query(ClaimBlack).filter(
            ClaimBlack.status.in_([ClaimStatus.PENDING.value, ClaimStatus.UNDER_REVIEW.value])
        ).order_by(desc(ClaimBlack.created_at)).offset(offset).limit(per_page).all()
        
        return {
            'items': cases,
            'total': total,
            'page': page,
            'pages': (total + per_page - 1) // per_page,
            'page_size': per_page
        }
    
    def update_case_status(self, case_id: str, status: str, notes: str = None, amount_recovered: float = None) -> ClaimBlack:
        """Admin: Update case status and metrics."""
        claim = self.db.query(ClaimBlack).filter(ClaimBlack.case_id == case_id.upper()).first()
        if not claim:
            raise ValueError("Case not found")
        
        claim.status = status
        claim.updated_at = datetime.utcnow()
        if notes:
            claim.case_description += f"\n\n--- ADMIN UPDATE {datetime.utcnow().strftime('%Y-%m-%d %H:%M')} ---\n{notes}"
        if amount_recovered is not None:
            claim.amount_recovered = amount_recovered
            if status == ClaimStatus.RECOVERED.value:
                claim.recovery_days = (claim.updated_at - claim.created_at).days
        
        self.db.commit()
        self.db.refresh(claim)
        return claim

