"""
Email Service — aiosmtplib + Stalwart Mail Server
--------------------------------------------------
Async email sending via aiosmtplib. SMTP config is read from:
  1. AdminSettings DB table (set via admin panel)
  2. Environment variables / .env file (fallback)

Falls back to console logging when no SMTP credentials are configured (dev mode).
"""
import asyncio
import os
import logging
from datetime import datetime
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from typing import Optional

import aiosmtplib
from sqlalchemy.orm import Session

from backend.core.config import settings

logger = logging.getLogger(__name__)


# ── SMTP Config ──────────────────────────────────────────────────────────────

def get_smtp_config(db: Optional[Session] = None) -> dict:
    """Read SMTP config from AdminSettings table, falling back to env/config."""
    config = {}
    if db:
        try:
            from backend.models.models import AdminSettings
            rows = db.query(AdminSettings).filter(
                AdminSettings.key.in_(
                    ["smtp_host", "smtp_port", "smtp_user", "smtp_pass", "smtp_from", "smtp_tls"]
                )
            ).all()
            for r in rows:
                config[r.key] = r.value
        except Exception:
            pass

    return {
        "host":     config.get("smtp_host")  or settings.SMTP_HOST,
        "port":     int(config.get("smtp_port") or settings.SMTP_PORT),
        "user":     config.get("smtp_user")  or settings.SMTP_USER,
        "password": config.get("smtp_pass")  or settings.SMTP_PASS,
        "from":     config.get("smtp_from")  or settings.SMTP_FROM,
        "tls":      (config.get("smtp_tls") or str(settings.SMTP_TLS)).lower() in ("true", "1", "yes"),
    }


# ── HTML Email Wrapper ───────────────────────────────────────────────────────

def build_html_email(body_html: str) -> str:
    year = datetime.now().year
    return f"""<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <style>
    body{{margin:0;padding:0;background:#050810;font-family:'Segoe UI',Arial,sans-serif;}}
    .wrap{{max-width:580px;margin:40px auto;background:#111827;border:1px solid #1e2d4a;border-radius:16px;overflow:hidden;}}
    .header{{background:linear-gradient(135deg,#0a0f1e 0%,#0f1628 100%);padding:32px;text-align:center;border-bottom:1px solid #1e2d4a;}}
    .logo{{font-size:1.6rem;font-weight:800;color:#fff;letter-spacing:-0.5px;}}
    .logo span{{color:#00d4aa;}}
    .tagline{{color:#6b7fa3;font-size:0.78rem;margin-top:6px;}}
    .body{{padding:36px 32px;color:#e8edf5;line-height:1.75;font-size:0.95rem;}}
    h2{{color:#fff;font-size:1.3rem;margin:0 0 16px;}}
    .highlight{{color:#00d4aa;font-weight:700;}}
    .amount{{font-size:2rem;font-weight:800;color:#00d4aa;font-family:monospace;}}
    .btn{{display:inline-block;background:#00d4aa;color:#050810 !important;padding:14px 36px;border-radius:10px;text-decoration:none;font-weight:700;font-size:1rem;margin:20px 0;}}
    .btn:hover{{background:#00c49a;}}
    .box{{background:#0a0f1e;border:1px solid #1e2d4a;border-radius:12px;padding:24px;margin:20px 0;text-align:center;}}
    .footer{{padding:20px 32px;border-top:1px solid #1e2d4a;text-align:center;font-size:0.75rem;color:#6b7fa3;}}
    .footer a{{color:#00d4aa;text-decoration:none;}}
    .divider{{height:1px;background:#1e2d4a;margin:24px 0;}}
    .warn{{color:#f59e0b;font-size:0.85rem;}}
  </style>
</head>
<body>
  <div class="wrap">
    <div class="header">
      <div class="logo">StrongNode<span>Capitals</span></div>
      <div class="tagline">Institutional Crypto Investment Platform</div>
    </div>
    <div class="body">{body_html}</div>
    <div class="footer">
      &copy; {year} StrongNode Capitals &nbsp;|&nbsp;
      <a href="{settings.APP_BASE_URL}">strongnodecapitals.com</a><br>
      This is an automated message. Please do not reply to this email.
    </div>
  </div>
</body>
</html>"""


# ── Core Async Send ──────────────────────────────────────────────────────────

async def _async_send(cfg: dict, to_email: str, subject: str, html: str) -> bool:
    """Send email via aiosmtplib (async, compatible with Stalwart Mail Server)."""
    msg = MIMEMultipart("alternative")
    msg["Subject"] = subject
    msg["From"]    = cfg["from"]
    msg["To"]      = to_email
    msg.attach(MIMEText(html, "html", "utf-8"))

    try:
        await aiosmtplib.send(
            msg,
            hostname=cfg["host"],
            port=cfg["port"],
            username=cfg["user"],
            password=cfg["password"],
            start_tls=cfg["tls"],
            timeout=15,
        )
        return True
    except aiosmtplib.SMTPException as e:
        logger.error(f"SMTP error sending to {to_email}: {e}")
        raise
    except Exception as e:
        logger.error(f"Unexpected email error to {to_email}: {e}")
        raise


def _run_async_send(cfg: dict, to_email: str, subject: str, html: str) -> bool:
    """
    Run async send from a sync context (background thread).
    Creates a new event loop so it works outside FastAPI's async context.
    """
    loop = asyncio.new_event_loop()
    try:
        loop.run_until_complete(_async_send(cfg, to_email, subject, html))
        return True
    except Exception as e:
        logger.error(f"Email send failed: {e}")
        return False
    finally:
        loop.close()


# ── Public send_email (sync wrapper — safe to call from sync routers) ────────

def send_email(
    to_email: str,
    subject: str,
    body_html: str,
    db: Optional[Session] = None,
    user_id: int = 0,
    notification_type: str = "general",
) -> bool:
    """Send an HTML email and log it to the database."""
    from backend.models.models import EmailNotificationLog

    full_html = build_html_email(body_html)
    cfg = get_smtp_config(db)

    # ── Log to DB ──────────────────────────────────────────────────────────
    log_status = "queued"
    log = EmailNotificationLog(
        user_id=user_id,
        recipient_email=to_email,
        subject=subject,
        body=body_html,
        notification_type=notification_type,
        status=log_status,
    )
    if db:
        try:
            db.add(log)
            db.commit()
            db.refresh(log)
        except Exception:
            db.rollback()

    # ── Dev mode: no credentials configured ───────────────────────────────
    if not cfg["user"] or not cfg["password"]:
        logger.info(
            f"\n📧 [EMAIL DEV MODE]\n"
            f"   To: {to_email}\n"
            f"   Subject: {subject}\n"
            f"   Type: {notification_type}\n"
            f"   Preview: {body_html[:140]}...\n"
        )
        if db:
            try:
                log.status = "dev_logged"
                db.commit()
            except Exception:
                pass
        return True

    # ── Send via aiosmtplib ────────────────────────────────────────────────
    success = _run_async_send(cfg, to_email, subject, full_html)
    if db:
        try:
            log.status = "sent" if success else "failed"
            db.commit()
        except Exception:
            pass
    return success


# ── Email Templates ──────────────────────────────────────────────────────────

def send_welcome_activation_email(
    to_email: str,
    full_name: str,
    activation_token: str,
    db: Optional[Session] = None,
    user_id: int = 0,
) -> bool:
    """
    Welcome email with account activation link.
    Sent to every new non-admin user on registration.
    """
    activation_link = f"{settings.APP_BASE_URL}/activate?token={activation_token}"
    expires_hours = settings.ACTIVATION_TOKEN_EXPIRE_HOURS

    subject = "🎉 Welcome to StrongNode Capitals — Activate Your Account"
    body = f"""
<h2>Welcome, {full_name}! 🎉</h2>
<p>Thank you for joining <strong>StrongNode Capitals</strong> — your institutional crypto investment platform.</p>
<p>To get started, please activate your account by clicking the button below:</p>

<div style="text-align:center;">
  <a href="{activation_link}" class="btn">✅ Activate My Account</a>
</div>

<div class="box">
  <div style="font-size:0.78rem;color:#6b7fa3;margin-bottom:6px;">ACTIVATION LINK</div>
  <div style="font-size:0.75rem;word-break:break-all;color:#00d4aa;">{activation_link}</div>
</div>

<p class="warn">⏰ This link expires in <strong>{expires_hours} hours</strong>. If it expires, you can request a new one from the login page.</p>

<div class="divider"></div>

<p>Once activated, you'll have full access to:</p>
<ul style="color:#6b7fa3;line-height:2.2;">
  <li><span class="highlight">Investment Plans</span> — earn daily ROI on your portfolio</li>
  <li><span class="highlight">Deposits & Withdrawals</span> — secure crypto transactions</li>
  <li><span class="highlight">Credit Advances</span> — borrow against your holdings</li>
  <li><span class="highlight">Scam Recovery</span> — expert fund recovery services</li>
</ul>

<p style="color:#6b7fa3;font-size:0.85rem;">
  If you did not create this account, please ignore this email — no action is required.
</p>
"""
    return send_email(to_email, subject, body, db, user_id, "activation")


def notify_account_activated(
    to_email: str,
    full_name: str,
    db: Optional[Session] = None,
    user_id: int = 0,
) -> bool:
    """Confirmation email sent after successful account activation."""
    subject = "✅ Account Activated — You're All Set!"
    body = f"""
<h2>Your Account is Now Active!</h2>
<p>Hi <strong>{full_name}</strong>,</p>
<p>Your StrongNode Capitals account has been successfully verified and activated.</p>

<div class="box">
  <div style="font-size:0.85rem;color:#6b7fa3;margin-bottom:8px;">ACCOUNT STATUS</div>
  <div style="font-size:1.4rem;font-weight:800;color:#00d4aa;">✅ ACTIVE</div>
</div>

<p>You can now log in and start investing. Complete your KYC to unlock all platform features.</p>

<div style="text-align:center;">
  <a href="{settings.APP_BASE_URL}/login" class="btn">Go to Dashboard →</a>
</div>
"""
    return send_email(to_email, subject, body, db, user_id, "activation_confirm")


def notify_profit(user_email, user_name, amount, new_balance, plan_name, db, user_id):
    subject = f"💰 Profit Credited: ${amount:.2f} — StrongNode Capitals"
    body = f"""
<h2>Your Daily Profit Has Been Credited!</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Your daily ROI from your <span class="highlight">{plan_name}</span> investment has been credited.</p>
<div class="box">
  <div style="font-size:0.85rem;color:#6b7fa3;margin-bottom:4px;">PROFIT CREDITED</div>
  <div class="amount">+${amount:.2f}</div>
  <div style="color:#6b7fa3;margin-top:8px;font-size:0.875rem;">New Balance: <strong style="color:#e8edf5;">${new_balance:.2f}</strong></div>
</div>
<div style="text-align:center;"><a href="{settings.APP_BASE_URL}/dashboard" class="btn">View Dashboard</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "profit")


def notify_kyc_approved(user_email, user_name, db, user_id):
    subject = "✅ KYC Verified — You're Fully Verified!"
    body = f"""
<h2>Identity Verification Approved</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<p>Your identity has been successfully verified. You now have full access to all platform features.</p>
<div style="text-align:center;"><a href="{settings.APP_BASE_URL}/dashboard" class="btn">Start Investing</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "kyc")


def notify_kyc_rejected(user_email, user_name, reason, db, user_id):
    subject = "❌ KYC Review — Action Required"
    body = f"""
<h2>Identity Verification — Resubmission Required</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<div style="background:#0a0f1e;border:1px solid #ff4d6d;border-radius:10px;padding:16px;margin:16px 0;color:#ff4d6d;">
  {reason or "Documents were unclear or incomplete. Please resubmit."}
</div>
<div style="text-align:center;"><a href="{settings.APP_BASE_URL}/dashboard" class="btn">Resubmit KYC</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "kyc")


def notify_deposit(user_email, user_name, amount, ref, db, user_id):
    subject = f"✅ Deposit Confirmed: ${amount:.2f}"
    body = f"""
<h2>Deposit Successfully Credited</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<div class="box">
  <div style="font-size:0.85rem;color:#6b7fa3;">AMOUNT CREDITED</div>
  <div class="amount">+${amount:.2f}</div>
  <div style="color:#6b7fa3;font-size:0.8rem;margin-top:8px;">Ref: {ref}</div>
</div>
<div style="text-align:center;"><a href="{settings.APP_BASE_URL}/dashboard" class="btn">View Dashboard</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "deposit")


def notify_withdrawal(user_email, user_name, amount, ref, db, user_id):
    subject = f"📤 Withdrawal Request: ${amount:.2f} — Processing"
    body = f"""
<h2>Withdrawal Request Received</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<div class="box">
  <div style="font-size:0.85rem;color:#6b7fa3;">WITHDRAWAL AMOUNT</div>
  <div class="amount">${amount:.2f}</div>
  <div style="color:#6b7fa3;font-size:0.8rem;margin-top:8px;">Ref: {ref}</div>
</div>
<p style="color:#6b7fa3;">Processing time: 24–48 hours.</p>
"""
    send_email(user_email, subject, body, db, user_id, "withdrawal")


def notify_bonus(user_email, user_name, amount, reason, db, user_id):
    subject = f"🎁 Bonus Credited: ${amount:.2f} — Welcome!"
    body = f"""
<h2>Welcome Bonus Credited!</h2>
<p>Hi <strong>{user_name}</strong>,</p>
<div class="box">
  <div style="font-size:0.85rem;color:#6b7fa3;">BONUS AMOUNT</div>
  <div class="amount">+${amount:.2f}</div>
</div>
<p>{reason}</p>
<div style="text-align:center;"><a href="{settings.APP_BASE_URL}/dashboard" class="btn">Start Investing</a></div>
"""
    send_email(user_email, subject, body, db, user_id, "bonus")


def send_recovery_email(to_email, subject, body_html, db=None, user_id=0, notification_type="recovery"):
    send_email(to_email, subject, body_html, db, user_id, notification_type)


def build_email_verification_email(verification_link):
    subject = "✅ Verify your email address"
    body = f"""
<h2>Email Verification Required</h2>
<p>Please verify that this email address belongs to you.</p>
<div style="text-align:center;margin:18px 0;">
  <a href="{verification_link}" class="btn">Verify Email</a>
</div>
<p>If you did not create an account, you can safely ignore this email.</p>
"""
    return subject, body
