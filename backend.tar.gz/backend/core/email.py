from backend.core.email_service import send_email
async def send_recovery_email(to_email, subject, body_html, db=None, user_id=0, notification_type='recovery'):
    return await send_email(to_email, subject, body_html, db, user_id, notification_type)

