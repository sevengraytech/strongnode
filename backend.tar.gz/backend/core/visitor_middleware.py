import logging
import threading
import time
from typing import Optional

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import Response

from sqlalchemy.orm import Session
from sqlalchemy import text

from backend.core.database import SessionLocal
from backend.models.visit_logs import VisitorLog

logger = logging.getLogger(__name__)

# How long to retain visitor logs (in seconds). Default: 7 days.
VISITOR_LOG_RETENTION_SECONDS = 7 * 24 * 60 * 60

# How often to run purge job (in seconds). Default: 1 day.
VISITOR_LOG_PURGE_INTERVAL_SECONDS = 24 * 60 * 60


def _get_client_ip(request: Request) -> str:
    """Best-effort IP extraction (supports reverse proxies via X-Forwarded-For)."""
    xff = request.headers.get("x-forwarded-for")
    if xff:
        # X-Forwarded-For can be a comma-separated list; first is original client.
        return xff.split(",")[0].strip()
    client = request.client
    return client.host if client else "unknown"


def _purge_old_visitor_logs_once(retention_seconds: int = VISITOR_LOG_RETENTION_SECONDS) -> int:
    """Delete visitor logs older than retention window. Returns deleted-row count."""
    cutoff_epoch = int(time.time() - retention_seconds)

    # SQLite stores `created_at` as a DATETIME; use `strftime` for epoch conversion.
    # This approach remains portable for the current SQLite setup.
    db: Session = SessionLocal()
    try:
        # `created_at` is timezone=True but sqlite stores text; strftime works if ISO-ish.
        result = db.execute(
            text(
                "DELETE FROM visitor_logs "
                "WHERE strftime('%s', created_at) < :cutoff"
            ),
            {"cutoff": cutoff_epoch},
        )
        db.commit()

        # SQLAlchemy's result rowcount may be -1 for some dialects; handle gracefully.
        deleted = getattr(result, "rowcount", None)
        return int(deleted) if deleted is not None and deleted != -1 else 0
    except Exception as e:
        logger.warning("Visitor log purge failed: %s", e)
        db.rollback()
        return 0
    finally:
        db.close()


def start_visitor_log_purge_daemon(
    retention_seconds: int = VISITOR_LOG_RETENTION_SECONDS,
    purge_interval_seconds: int = VISITOR_LOG_PURGE_INTERVAL_SECONDS,
) -> None:
    """Start background daemon that periodically purges old visitor logs.

    Runs in-process so it works in simple deployments without external schedulers.
    """

    # Avoid starting multiple daemons (e.g., in reload scenarios)
    global _visitor_log_purge_started
    if globals().get("_visitor_log_purge_started"):
        return
    _visitor_log_purge_started = True

    def _runner():
        # Small delay so startup isn't impacted
        time.sleep(2)
        while True:
            try:
                _purge_old_visitor_logs_once(retention_seconds=retention_seconds)
            except Exception:
                # _purge already handles/logs, but keep loop resilient
                pass
            time.sleep(purge_interval_seconds)

    t = threading.Thread(target=_runner, name="visitor-log-purge", daemon=True)
    t.start()


class VisitorLoggingMiddleware(BaseHTTPMiddleware):

    """Logs landing-page visitor IP + (optional) location into DB for admin analytics.

    "location" is currently stored as null because no geoip dependency is included.
    """

    def __init__(
        self,
        app,
        enabled: bool = True,
        log_authenticated_users: bool = True,
        # Avoid spamming logs: once per (ip,path) within this many seconds.
        dedup_seconds: int = 60,
    ):
        super().__init__(app)
        self.enabled = enabled
        self.log_authenticated_users = log_authenticated_users
        self.dedup_seconds = dedup_seconds

    def _should_log_landing(self, request: Request) -> bool:
        # Landing page is served at '/'
        if request.url.path != "/":
            return False
        # Log GET only (avoid POSTs etc.)
        if request.method.upper() != "GET":
            return False
        return True

    async def dispatch(self, request: Request, call_next):
        if self.enabled and self._should_log_landing(request):
            try:
                user_id = None
                if self.log_authenticated_users:
                    user = getattr(request.state, "user", None)
                    user_id = getattr(user, "id", None) if user else None

                ip = _get_client_ip(request)
                user_agent = request.headers.get("user-agent")

                # Deduplicate in-memory to reduce duplicates from rapid refreshes.
                # Keyed by ip + landing path.
                now = time.time()

                if not hasattr(self, "_recent"):
                    self._recent = {}

                key = f"{ip}|{request.url.path}"
                last = self._recent.get(key)
                if last is None or (now - last) >= self.dedup_seconds:
                    self._recent[key] = now
                    db: Session = SessionLocal()
                    try:
                        db.add(
                            VisitorLog(
                                user_id=user_id,
                                ip_address=ip,
                                location=None,
                                user_agent=user_agent,
                                path=request.url.path,
                                method=request.method,
                            )
                        )
                        db.commit()
                    finally:
                        db.close()
            except Exception as e:
                # Never block requests due to logging.
                logger.debug("Visitor logging failed: %s", e)

        response: Optional[Response] = await call_next(request)
        return response


