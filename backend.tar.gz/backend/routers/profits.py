from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, ProfitLog
from backend.schemas.schemas import ProfitLogOut
from typing import List

router = APIRouter(prefix="/profits", tags=["Profits"])

@router.get("", response_model=List[ProfitLogOut])
def get_profit_logs(
    limit: int = Query(50, ge=1, le=200),
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db)
):
    return db.query(ProfitLog).filter(ProfitLog.user_id == current_user.id)\
        .order_by(ProfitLog.date.desc()).limit(limit).all()
