"""
Password Reset — DB-backed tokens.

Flow:
  1. POST /auth/forgot-password  {email}
       → generates a token, stores SHA-256 hash in DB, emails raw token link to user
  2. User clicks link → /reset-password?token=<raw>
  3. POST /auth/reset-password   {token, new_password}
       → hashes token, looks up DB, validates expiry, updates password
"""
import hashlib
import secrets
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel, EmailStr
from sqlalchemy.orm import Session

from backend.core.config import settings
from backend.core.database import get_db
from backend.core.email_service import send_email
from backend.core.security import get_password_hash
from backend.models.models import PasswordResetToken, User

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ── helpers ──────────────────────────────────────────────────────────────────

def _hash(raw: str) -> str:
    return hashlib.sha256(raw.encode()).hexdigest()


def _build_reset_email(token: str) -> tuple[str, str]:
    link = f"{settings.APP_BASE_URL}/reset-password?token={token}"
    subject = "🔐 Password Reset — StrongNode Capitals"
    body = f"""
<h2>Password Reset Requested</h2>
<p>We received a request to reset your <strong>StrongNode Capitals</strong> password.</p>

<div style="text-align:center;margin:28px 0;">
  <a href="{link}" class="btn">Reset My Password</a>
</div>

<div class="box">
  <div style="font-size:0.75rem;color:#6b7fa3;margin-bottom:6px;">OR COPY THIS LINK</div>
  <div style="font-size:0.75rem;word-break:break-all;color:#00d4aa;">{link}</div>
</div>

<p class="warn">⏰ This link expires in <strong>1 hour</strong>.</p>
<p style="color:#6b7fa3;font-size:0.85rem;">
  If you did not request a password reset, you can safely ignore this email.
  Your password will not be changed.
</p>
"""
    return subject, body


# ── schemas ───────────────────────────────────────────────────────────────────

class ForgotPasswordRequest(BaseModel):
    email: EmailStr


class ResetPasswordRequest(BaseModel):
    token: str
    new_password: str


# ── endpoints ─────────────────────────────────────────────────────────────────

@router.post("/forgot-password")
def forgot_password(data: ForgotPasswordRequest, db: Session = Depends(get_db)):
    # Generic response — never reveal whether the email exists
    generic_ok = {"message": "If that email is registered, a reset link has been sent."}

    user = db.query(User).filter(User.email == data.email).first()
    if not user:
        return generic_ok

    # Invalidate all previous unused tokens for this user
    db.query(PasswordResetToken).filter(
        PasswordResetToken.user_id == user.id,
        PasswordResetToken.used == False,
    ).delete(synchronize_session=False)

    raw_token = secrets.token_urlsafe(32)
    db.add(PasswordResetToken(
        user_id   = user.id,
        email     = user.email,
        token_hash= _hash(raw_token),
        expires_at= datetime.utcnow() + timedelta(hours=1),
    ))
    db.commit()

    subject, body = _build_reset_email(raw_token)
    try:
        send_email(user.email, subject, body, db, user.id, "password_reset")
    except Exception as e:
        # Log the failure but never reveal it to the caller —
        # the token is already saved, so the user can still use the link
        # if the email was actually delivered (or retry via the endpoint).
        import logging
        logging.getLogger(__name__).error(
            f"[PASSWORD_RESET] Email delivery failed for {user.email}: {e}"
        )

    return generic_ok


@router.post("/reset-password")
def reset_password(data: ResetPasswordRequest, db: Session = Depends(get_db)):
    if not data.token or not data.token.strip():
        raise HTTPException(status_code=400, detail="Reset token is required.")

    if len(data.new_password) < 8:
        raise HTTPException(status_code=400, detail="Password must be at least 8 characters.")

    record = db.query(PasswordResetToken).filter(
        PasswordResetToken.token_hash == _hash(data.token),
        PasswordResetToken.used       == False,
    ).first()

    if not record:
        raise HTTPException(
            status_code=400,
            detail="Invalid or already-used reset link. Please request a new one."
        )

    if record.expires_at < datetime.utcnow():
        record.used = True
        db.commit()
        raise HTTPException(
            status_code=400,
            detail="This reset link has expired. Please request a new one."
        )

    user = db.query(User).filter(User.id == record.user_id).first()
    if not user:
        raise HTTPException(status_code=400, detail="User not found.")

    user.hashed_password = get_password_hash(data.new_password)
    record.used = True
    db.commit()

    return {"message": "Password updated successfully. You can now log in with your new password."}
