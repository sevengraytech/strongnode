from fastapi import APIRouter, Depends, HTTPException, status, BackgroundTasks
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import verify_password, get_password_hash, create_access_token
from backend.core.email_service import (
    notify_bonus,
    send_welcome_activation_email,
    notify_account_activated,
)
from backend.core.config import settings
from backend.models.models import (
    User,
    PromoCode,
    Transaction,
    TransactionType,
    TransactionStatus,
)
from backend.schemas.schemas import UserRegister, UserLogin, Token
from datetime import datetime, timedelta
import secrets
import threading

router = APIRouter(prefix="/auth", tags=["Authentication"])


# ── Helpers ──────────────────────────────────────────────────────────────────

def generate_wallet() -> str:
    return "0x" + secrets.token_hex(20)


def generate_activation_token() -> str:
    """Cryptographically secure URL-safe token."""
    return secrets.token_urlsafe(48)


def _run_in_thread(fn, *args):
    """Fire-and-forget a function in a daemon thread (keeps request fast)."""
    t = threading.Thread(target=fn, args=args, daemon=True)
    t.start()


def _send_welcome_email(email: str, full_name: str, token: str, user_id: int):
    """Called from background thread — opens its own DB session."""
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        send_welcome_activation_email(email, full_name, token, db, user_id)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"[EMAIL] Welcome email failed for {email}: {e}")
    finally:
        db.close()


def _send_bonus_email(email: str, name: str, amount: float, reason: str, user_id: int):
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        notify_bonus(email, name, amount, reason, db, user_id)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"[EMAIL] Bonus email failed for {email}: {e}")
    finally:
        db.close()


def _send_activated_email(email: str, full_name: str, user_id: int):
    from backend.core.database import SessionLocal
    db = SessionLocal()
    try:
        notify_account_activated(email, full_name, db, user_id)
        db.commit()
    except Exception as e:
        db.rollback()
        print(f"[EMAIL] Activation confirm email failed for {email}: {e}")
    finally:
        db.close()


# ── Register ─────────────────────────────────────────────────────────────────

@router.post("/register", response_model=Token, status_code=status.HTTP_201_CREATED)
def register(data: UserRegister, db: Session = Depends(get_db)):

    if db.query(User).filter(User.email == data.email).first():
        raise HTTPException(status_code=400, detail="Email already registered")

    # ── Validate promo code ──────────────────────────────────────────────
    promo = None
    bonus_amount = 0.0
    promo_reason = ""

    # ── Referral attribution at registration time ────────────────────────
    referral_user_id = None
    referral_code_str = (getattr(data, 'referral_code', None) or '').strip().upper() if data else ''


    if data.promo_code:
        code_str = data.promo_code.strip().upper()
        promo = db.query(PromoCode).filter(
            PromoCode.code == code_str,
            PromoCode.is_active == True,
        ).first()
        if not promo:
            raise HTTPException(status_code=400, detail="Invalid or expired promo code")
        if promo.used_count >= promo.max_uses:
            raise HTTPException(status_code=400, detail="Promo code has reached its usage limit")
        if promo.expires_at and datetime.utcnow() > promo.expires_at:
            raise HTTPException(status_code=400, detail="Promo code has expired")
        bonus_amount = promo.bonus_amount
        promo_reason = f"promo code <strong>{code_str}</strong> applied"

    # ── Generate activation token (not needed for admins) ────────────────
    # Admin emails are activated immediately; regular users must click the link.
    is_admin_email = data.email.lower() in (
        "strongnodecapital@mailfence.com",
        "sweetmail@gmail.com",
    )
    activation_token = None
    activation_expires = None

    if not is_admin_email:
        activation_token = generate_activation_token()
        activation_expires = datetime.utcnow() + timedelta(
            hours=settings.ACTIVATION_TOKEN_EXPIRE_HOURS
        )

    # Resolve referral code (optional)
    # Referral codes refer to another user by referral_code; we only set referrer_user_id once.
    if referral_code_str:
        ref_user = db.query(User).filter(User.referral_code == referral_code_str).first()
        if ref_user:
            referral_user_id = ref_user.id

    # ── Create user ──────────────────────────────────────────────────────
    user = User(

        email=data.email,
        full_name=data.full_name,
        hashed_password=get_password_hash(data.password),
        mobile=data.mobile,
        country=data.country,
        address=data.address,
        city=data.city,
        state=data.state,
        date_of_birth=data.date_of_birth,
        wallet_address=generate_wallet(),
        balance=bonus_amount,
        bonus_credited=bool(promo),
        promo_code_used=promo.code if promo else None,
        referral_code="REF-" + secrets.token_hex(6).upper(),
        referrer_user_id=referral_user_id,

        # Admins are activated immediately; regular users start inactive
        email_verified=is_admin_email,
        registration_completed=True,
        is_admin=is_admin_email,
        activation_token=activation_token,
        activation_token_expires_at=activation_expires,
    )

    db.add(user)
    db.flush()  # get user.id before commit

    # ── Credit bonus transaction ─────────────────────────────────────────
    if promo:
        db.add(Transaction(
            user_id=user.id,
            type=TransactionType.BONUS,
            amount=bonus_amount,
            status=TransactionStatus.COMPLETED,
            description=f"Welcome bonus — {promo_reason}",
            reference="BON-" + secrets.token_hex(6).upper(),
        ))
        promo.used_count += 1

    db.commit()
    db.refresh(user)

    # ── Fire emails in background threads ────────────────────────────────
    if not is_admin_email:
        # Regular user → send welcome + activation email
        _run_in_thread(
            _send_welcome_email,
            user.email, user.full_name, activation_token, user.id,
        )
    if promo:
        _run_in_thread(
            _send_bonus_email,
            user.email, user.full_name, bonus_amount, promo_reason, user.id,
        )

    # ── Build response ───────────────────────────────────────────────────
    # For non-admin users we still return a token so the frontend can show
    # a "check your email" page — but the token is valid, login is gated
    # separately on email_verified.
    token = create_access_token({"sub": user.email})

    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "mobile": user.mobile,
            "country": user.country,
            "address": user.address,
            "city": user.city,
            "state": user.state,
            "date_of_birth": user.date_of_birth,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "is_admin": user.is_admin,
            "email_verified": user.email_verified,
            "bonus_amount": bonus_amount,
            "promo_used": promo.code if promo else None,
            # Tell the frontend whether to show the "check your email" screen
            "needs_activation": not user.email_verified,
        },
    }


# ── Activate Account ─────────────────────────────────────────────────────────

@router.get("/activate")
def activate_account(token: str, db: Session = Depends(get_db)):
    """
    Called when the user clicks the link in their welcome email.
    Marks the account as verified and clears the token.
    Returns JSON so the activate.html page can react properly.
    """
    if not token:
        raise HTTPException(status_code=400, detail="Activation token is required")

    user = db.query(User).filter(User.activation_token == token).first()

    if not user:
        raise HTTPException(status_code=404, detail="Invalid or already-used activation link")

    if user.email_verified:
        # Already activated — just let them log in
        return {"success": True, "already_active": True, "message": "Account already activated. Please log in."}

    if user.activation_token_expires_at and datetime.utcnow() > user.activation_token_expires_at:
        raise HTTPException(
            status_code=400,
            detail="Activation link has expired. Please request a new one.",
        )

    # ── Activate ─────────────────────────────────────────────────────────
    user.email_verified = True
    user.activation_token = None
    user.activation_token_expires_at = None
    db.commit()
    db.refresh(user)

    # Send confirmation email in background
    _run_in_thread(_send_activated_email, user.email, user.full_name, user.id)

    return {
        "success": True,
        "already_active": False,
        "message": f"Account activated! Welcome to StrongNode Capitals, {user.full_name}.",
    }


# ── Resend Activation Email ───────────────────────────────────────────────────

@router.post("/resend-activation")
def resend_activation(email: str, db: Session = Depends(get_db)):
    """Let users request a fresh activation link if theirs expired."""
    user = db.query(User).filter(User.email == email).first()

    # Return generic message regardless — don't leak whether email exists
    generic_ok = {"message": "If that email is registered and unactivated, a new link has been sent."}

    if not user or user.email_verified or user.is_admin:
        return generic_ok

    # Generate a new token
    new_token = generate_activation_token()
    user.activation_token = new_token
    user.activation_token_expires_at = datetime.utcnow() + timedelta(
        hours=settings.ACTIVATION_TOKEN_EXPIRE_HOURS
    )
    db.commit()

    _run_in_thread(_send_welcome_email, user.email, user.full_name, new_token, user.id)
    return generic_ok


# ── Login ─────────────────────────────────────────────────────────────────────

@router.post("/login", response_model=Token)
def login(data: UserLogin, db: Session = Depends(get_db)):
    user = db.query(User).filter(User.email == data.email).first()

    if not user or not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=401, detail="Invalid email or password")

    if not user.is_active:
        raise HTTPException(status_code=403, detail="Account has been disabled. Contact support.")

    # Gate on email activation for non-admin users
    if not user.email_verified and not user.is_admin:
        raise HTTPException(
            status_code=403,
            detail="Account not activated. Please check your email and click the activation link.",
        )

    token = create_access_token({"sub": user.email})
    return {
        "access_token": token,
        "token_type": "bearer",
        "expires_in": 3600,
        "user": {
            "id": user.id,
            "email": user.email,
            "full_name": user.full_name,
            "balance": user.balance,
            "wallet_address": user.wallet_address,
            "kyc_status": user.kyc_status,
            "is_admin": user.is_admin,
            "email_verified": user.email_verified,
            "promo_used": user.promo_code_used,
            "needs_activation": False,
        },
    }


# ── Validate Promo ────────────────────────────────────────────────────────────

@router.get("/validate-promo/{code}")
def validate_promo(code: str, db: Session = Depends(get_db)):
    promo = db.query(PromoCode).filter(
        PromoCode.code == code.strip().upper(),
        PromoCode.is_active == True,
    ).first()
    if not promo or promo.used_count >= promo.max_uses:
        raise HTTPException(status_code=404, detail="Invalid or expired promo code")
    if promo.expires_at and datetime.utcnow() > promo.expires_at:
        raise HTTPException(status_code=404, detail="Promo code has expired")
    return {"valid": True, "bonus_amount": promo.bonus_amount, "description": promo.description}
