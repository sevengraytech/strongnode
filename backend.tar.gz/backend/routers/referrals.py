
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
import secrets

from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User, Transaction, TransactionType

import logging

router = APIRouter(prefix="/user/referrals", tags=["Referrals"])
logger = logging.getLogger(__name__)

@router.post("/apply")
def apply_referral_code(
    payload: dict,
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Associate current user with a referrer based on a referral code.

    Only allowed before the user has a referrer or before making their first deposit.
    Generates a referral code for the user if they don't have one.
    """
    raw = (payload.get("referral_code") or "").strip().upper()
    if not raw:
        raise HTTPException(status_code=400, detail="referral_code is required")

    if current_user.referrer_user_id:
        raise HTTPException(status_code=400, detail="Referral code already applied")

    has_prior_deposit = db.query(Transaction).filter(
        Transaction.user_id == current_user.id,
        Transaction.type == TransactionType.DEPOSIT,
    ).first()
    if has_prior_deposit:
        raise HTTPException(status_code=400, detail="Cannot apply referral after deposit")

    if not current_user.referral_code:
        current_user.referral_code = "REF-" + secrets.token_hex(6).upper()

    ref_user = db.query(User).filter(User.referral_code == raw).first()
    if not ref_user or ref_user.id == current_user.id:
        raise HTTPException(status_code=400, detail="Invalid referral code")

    current_user.referrer_user_id = ref_user.id
    db.add(current_user)
    db.commit()
    db.refresh(current_user)

    return {
        "success": True,
        "referral_code": current_user.referral_code,
        "referrer_user_id": current_user.referrer_user_id,
    }

@router.post("/generate")
def generate_referral_code(
    current_user: User = Depends(get_current_user),
    db: Session = Depends(get_db),
):
    """Generate (random) a referral code for the current user.

    This overwrites the existing code to ensure the user gets a fresh random code
    whenever they click the button.
    """
    current_user.referral_code = "REF-" + secrets.token_hex(6).upper()
    db.add(current_user)
    db.commit()
    db.refresh(current_user)
    return {
        "success": True,
        "referral_code": current_user.referral_code,
    }


@router.get("/validate/{code}")
def validate_referral_code(code: str, db: Session = Depends(get_db)):
    """Validate a referral code without authentication (for registration page)."""
    raw = (code or "").strip().upper()
    if not raw:
        raise HTTPException(status_code=400, detail="Referral code required")
    ref_user = db.query(User).filter(User.referral_code == raw).first()
    if not ref_user:
        raise HTTPException(status_code=404, detail="Invalid referral code")
    return {"valid": True, "referrer_name": ref_user.full_name}


