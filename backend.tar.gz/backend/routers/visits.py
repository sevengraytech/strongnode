from fastapi import APIRouter, Depends, Query, HTTPException
from sqlalchemy.orm import Session
from backend.core.database import get_db
from backend.core.security import get_current_user
from backend.models.models import User
from backend.models.visit_logs import VisitorLog
from backend.schemas.visit_logs_schemas import PaginatedVisitorLogs

router = APIRouter(prefix="/admin", tags=["Admin"])



def admin_required(current_user: User = Depends(get_current_user)):
    if not current_user.is_admin:
        raise HTTPException(status_code=403, detail="Admin access required")
    return current_user


@router.get("/visitor-logs", response_model=PaginatedVisitorLogs)
def list_visitor_logs(
    page: int = Query(1, ge=1),
    per_page: int = Query(50, ge=1, le=200),
    ip: str | None = None,
    admin: User = Depends(admin_required),
    db: Session = Depends(get_db),
):
    q = db.query(VisitorLog).order_by(VisitorLog.created_at.desc())
    if ip:
        q = q.filter(VisitorLog.ip_address == ip)

    total = q.count()
    items = q.offset((page - 1) * per_page).limit(per_page).all()

    return {
        "items": [
            {
                "id": l.id,
                "ip_address": l.ip_address,
                "location": l.location,
                "user_agent": l.user_agent,
                "path": l.path,
                "method": l.method,
                "user_id": l.user_id,
                "created_at": l.created_at.isoformat() if l.created_at else None,
            }
            for l in items
        ],
        "total": total,
        "page": page,
        "pages": max(1, (total + per_page - 1) // per_page),
        "page_size": per_page,
    }

